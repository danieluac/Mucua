<?php
require_once "config/defined.php";
require_once "extra/Fonte/autoleitura.php";
require_once "extra/Upload/autoload.php";
require_once "config/database.php";
require_once "config/assets.php";
require_once "config/view.php";
require_once "model/model.php";
require_once "controller/InterfaceController.php";
require_once "controller/controller.php";
require_once "kernel/kernel.php";
