<?php
use Fonte\Basedados\Capsula\Capsula;

$capsula = new Capsula();
$capsula->Conectando
        ([
            "socket" => "mysql",
            "endereco" => "localhost",
            "bdados" => "mucua",
            "usuario" => "root",
            "senha" => "",
            "charset" => "utf8"
        ]);

        $capsula->Selado();
