<?php
namespace app\config;

class defined
{
	/**
	*@const address your app
	**/
  const HOST_PUBLIC = "/MucuaApi/public/";
}
