<?php
namespace app\controller;

/**
 *
 * @author daniel-u-ac
 */
interface InterfaceController
{
    public function header($title);
    public function footer();
}
