<?php
namespace Fonte\Basedados\modelo;

/**
 * Description of user
 *
 * @author Daniel-U-AC
 */
class user extends Modelo
{

    // protected $tabela="Pensador";
   protected $colunas = ["usuario","senha"];

}
