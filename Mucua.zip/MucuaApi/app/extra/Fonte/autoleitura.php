<?php
require_once 'DataQueryObject/Capsula/Capsula.php';
require_once 'DataQueryObject/Tratamento/CriterioSelecao.php';
require_once 'DataQueryObject/Tratamento/Configuracao.php';
require_once 'DataQueryObject/Tratamento/Insert.php';
require_once 'DataQueryObject/Tratamento/Update.php';
require_once 'DataQueryObject/Tratamento/Delete.php';
require_once 'DataQueryObject/Tratamento/Select.php';
require_once 'DataQueryObject/modelo/ConfigModelo.php';
require_once 'DataQueryObject/modelo/Modelo.php';
/*require_once 'Basedados/Modelo/user.php';
use Fonte\Basedados\modelo\user;
$us = new user();

//print_r($us);

$us->where("iduser", "=", 6);
//$us->where("id", "=", 15,"and");
print_r($us);
print "<br/><br/>";
print_r($d = $us->selects(3));

print "<br/><br/>";
print_r($us);

print "<br/><br/> Usuario :";
if(isset($d->senha))print $d->senha;
print "<br/><br/>"; */
 