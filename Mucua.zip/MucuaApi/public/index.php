<?php
require_once __DIR__.DIRECTORY_SEPARATOR."../app/autoload.php";

use app\kernel\kernel;

return new kernel();
